
# -*- coding: utf-8 -*-
import os
import numpy as np
from keras.models import load_model
from keras.preprocessing import image
import matplotlib.pyplot as plt

test_image=os.listdir('test_image')
model=load_model('model.h5')
for fn in test_image:
  path='test_image/' + fn
  img=image.load_img(path, target_size=(150, 150))
  plt.imshow(img)
  plt.show()
  x=image.img_to_array(img)
  x=np.expand_dims(x, axis=0)
  images = np.vstack([x])
  classes = model.predict(images, batch_size=10)
  if classes[0]>0:
    print(fn + " is a dog")
  else:
    print(fn + " is a cat")